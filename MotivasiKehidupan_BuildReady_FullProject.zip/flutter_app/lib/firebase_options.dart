// Placeholder: run `flutterfire configure` to generate firebase_options.dart
class DefaultFirebaseOptions { static get currentPlatform => null; }
