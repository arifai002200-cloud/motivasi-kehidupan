import 'package:flutter/material.dart';
import '../widgets/quote_card.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dashboard')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: const [
          QuoteCard(text: 'Bangun dan lakukan yang terbaik hari ini.', author: 'Anonim'),
          SizedBox(height:12),
          QuoteCard(text: 'Satu langkah kecil lebih baik daripada tidak sama sekali.', author: 'Anonim'),
        ],
      ),
    );
  }
}
