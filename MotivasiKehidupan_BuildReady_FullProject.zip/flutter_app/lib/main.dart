import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'services/navigation.dart';
import 'theme.dart';
import 'screens/login_screen.dart';
import 'screens/dashboard_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Motivasi Kehidupan',
      navigatorKey: navigatorKey,
      theme: lightTheme,
      darkTheme: darkTheme,
      home: const LoginScreen(),
      routes: {
        '/dashboard': (_) => const DashboardScreen(),
      },
    );
  }
}
