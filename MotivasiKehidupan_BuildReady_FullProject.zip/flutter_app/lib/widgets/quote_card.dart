import 'package:flutter/material.dart';
class QuoteCard extends StatelessWidget {
  final String text;
  final String author;
  const QuoteCard({super.key, required this.text, required this.author});
  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(text, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height:8),
          Align(alignment: Alignment.centerRight, child: Text('- ' + author, style: Theme.of(context).textTheme.bodySmall)),
        ]),
      ),
    );
  }
}
