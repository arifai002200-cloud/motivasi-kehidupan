Motivasi Kehidupan - Build-Ready Project

This project is prepared to be built on CI (e.g. Codemagic) or locally.

Location: flutter_app/

Quick local build steps:
1. cd flutter_app
2. flutter pub get
3. flutterfire configure
4. flutter run
5. flutter build appbundle --release

Using Codemagic:
1. Push this repo to GitHub.
2. Sign in to https://codemagic.io with GitHub.
3. Create a new app and select this repo.
4. Use the provided workflow (codemagic.yaml) or create a workflow that runs `flutter build appbundle --release`.
5. Download the generated AAB or APK.

Notes:
- Firebase project id: motivasi-kehidupan
- If codemagic environment does not have flutterfire CLI installed, you may need to generate lib/firebase_options.dart locally using flutterfire configure.
